
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randommod.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.randommod.item.WeakjointItem;
import net.mcreator.randommod.item.SoakedCocoaBeansItem;
import net.mcreator.randommod.item.JointItem;
import net.mcreator.randommod.item.HempleafItem;
import net.mcreator.randommod.item.HashCookieItem;
import net.mcreator.randommod.item.DecarbedbudItem;
import net.mcreator.randommod.item.CocaineItem;
import net.mcreator.randommod.item.ClothBandageItem;
import net.mcreator.randommod.HempandstuffMod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class HempandstuffModItems {
	public static Item HEMP_BUSH_STAGE_1;
	public static Item HEMP_FLOWER;
	public static Item HEMPLEAF;
	public static Item HEMP_BUD;
	public static Item CLOTH_BANDAGE;
	public static Item LACED_JOINT;
	public static Item WEAKJOINT;
	public static Item DECARBEDBUD;
	public static Item HASH_COOKIE;
	public static Item SOAKED_COCOA_BEANS;
	public static Item COCAINE;

	public static void load() {
		HEMP_BUSH_STAGE_1 = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "hemp_bush_stage_1"), new BlockItem(HempandstuffModBlocks.HEMP_BUSH_STAGE_1, new Item.Properties()));
		HEMP_FLOWER = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "hemp_flower"), new BlockItem(HempandstuffModBlocks.HEMP_FLOWER, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(HempandstuffModTabs.TAB_RANDOM_MOD).register(content -> content.accept(HEMP_FLOWER));
		HEMPLEAF = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "hempleaf"), new HempleafItem());
		HEMP_BUD = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "hemp_bud"), new BlockItem(HempandstuffModBlocks.HEMP_BUD, new Item.Properties()));
		CLOTH_BANDAGE = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "cloth_bandage"), new ClothBandageItem());
		LACED_JOINT = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "laced_joint"), new JointItem());
		WEAKJOINT = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "weakjoint"), new WeakjointItem());
		DECARBEDBUD = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "decarbedbud"), new DecarbedbudItem());
		HASH_COOKIE = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "hash_cookie"), new HashCookieItem());
		SOAKED_COCOA_BEANS = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "soaked_cocoa_beans"), new SoakedCocoaBeansItem());
		COCAINE = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(HempandstuffMod.MODID, "cocaine"), new CocaineItem());
	}
}
