
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randommod.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.randommod.HempandstuffMod;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class HempandstuffModTabs {
	public static ResourceKey<CreativeModeTab> TAB_RANDOM_MOD = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(HempandstuffMod.MODID, "random_mod"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_RANDOM_MOD,
				FabricItemGroup.builder().title(Component.translatable("item_group." + HempandstuffMod.MODID + ".random_mod")).icon(() -> new ItemStack(HempandstuffModBlocks.HEMP_FLOWER)).build());
	}
}
