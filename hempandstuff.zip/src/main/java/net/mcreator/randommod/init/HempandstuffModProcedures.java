
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randommod.init;

import net.mcreator.randommod.procedures.WeakjoinrightclickedProcedure;
import net.mcreator.randommod.procedures.JointRightclickedProcedure;
import net.mcreator.randommod.procedures.HighEffectStartedappliedProcedure;
import net.mcreator.randommod.procedures.HempBushUpdateTickProcedure;
import net.mcreator.randommod.procedures.HempBushStage1UpdateTickProcedure;
import net.mcreator.randommod.procedures.HempBushBlockIsPlacedByProcedure;
import net.mcreator.randommod.procedures.HashCookieOnPlayerStoppedUsingProcedure;
import net.mcreator.randommod.procedures.GrasscheckProcedure;
import net.mcreator.randommod.procedures.DecarbedbudPlayerFinishesUsingItemProcedure;
import net.mcreator.randommod.procedures.CocaineUseProcedure;
import net.mcreator.randommod.procedures.ClothBandageRightclickedProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class HempandstuffModProcedures {
	public static void load() {
		new HempBushStage1UpdateTickProcedure();
		new HempBushUpdateTickProcedure();
		new HempBushBlockIsPlacedByProcedure();
		new GrasscheckProcedure();
		new ClothBandageRightclickedProcedure();
		new JointRightclickedProcedure();
		new HighEffectStartedappliedProcedure();
		new WeakjoinrightclickedProcedure();
		new DecarbedbudPlayerFinishesUsingItemProcedure();
		new HashCookieOnPlayerStoppedUsingProcedure();
		new CocaineUseProcedure();
	}
}
