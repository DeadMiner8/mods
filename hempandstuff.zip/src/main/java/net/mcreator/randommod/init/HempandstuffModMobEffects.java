
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randommod.init;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.randommod.potion.HighMobEffect;
import net.mcreator.randommod.HempandstuffMod;

public class HempandstuffModMobEffects {
	public static MobEffect HIGH;

	public static void load() {
		HIGH = Registry.register(BuiltInRegistries.MOB_EFFECT, new ResourceLocation(HempandstuffMod.MODID, "high"), new HighMobEffect());
	}
}
