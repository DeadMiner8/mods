
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randommod.init;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.randommod.block.entity.HempBushStage1BlockEntity;
import net.mcreator.randommod.block.entity.HempBushBlockEntity;
import net.mcreator.randommod.HempandstuffMod;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

public class HempandstuffModBlockEntities {
	public static BlockEntityType<?> HEMP_BUSH_STAGE_1;
	public static BlockEntityType<?> HEMP_FLOWER;

	public static void load() {
		HEMP_BUSH_STAGE_1 = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, new ResourceLocation(HempandstuffMod.MODID, "hemp_bush_stage_1"),
				FabricBlockEntityTypeBuilder.create(HempBushStage1BlockEntity::new, HempandstuffModBlocks.HEMP_BUSH_STAGE_1).build(null));
		HEMP_FLOWER = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, new ResourceLocation(HempandstuffMod.MODID, "hemp_flower"), FabricBlockEntityTypeBuilder.create(HempBushBlockEntity::new, HempandstuffModBlocks.HEMP_FLOWER).build(null));
	}
}
