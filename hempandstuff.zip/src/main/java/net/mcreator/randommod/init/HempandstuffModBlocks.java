
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randommod.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.randommod.block.HempBushStage1Block;
import net.mcreator.randommod.block.HempBushBlock;
import net.mcreator.randommod.block.HempBudBlock;
import net.mcreator.randommod.HempandstuffMod;

public class HempandstuffModBlocks {
	public static Block HEMP_BUSH_STAGE_1;
	public static Block HEMP_FLOWER;
	public static Block HEMP_BUD;

	public static void load() {
		HEMP_BUSH_STAGE_1 = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(HempandstuffMod.MODID, "hemp_bush_stage_1"), new HempBushStage1Block());
		HEMP_FLOWER = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(HempandstuffMod.MODID, "hemp_flower"), new HempBushBlock());
		HEMP_BUD = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(HempandstuffMod.MODID, "hemp_bud"), new HempBudBlock());
	}

	public static void clientLoad() {
		HempBushStage1Block.clientInit();
		HempBushBlock.clientInit();
		HempBudBlock.clientInit();
	}
}
