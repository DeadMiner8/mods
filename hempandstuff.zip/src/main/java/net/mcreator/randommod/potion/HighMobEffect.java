
package net.mcreator.randommod.potion;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.randommod.procedures.HighEffectStartedappliedProcedure;

public class HighMobEffect extends MobEffect {
	public HighMobEffect() {
		super(MobEffectCategory.HARMFUL, -16738048);
	}

	@Override
	public String getDescriptionId() {
		return "effect.hempandstuff.high";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();

		HighEffectStartedappliedProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
